
public class Ceil {
	/**
	 * Trouve dans l'arbre le plus petit élément plus grand ou égal à value 
	 * (donc soit l'élément lui-même soit l'élément situé directement après par ordre de grandeur). 
	 * Si un tel élément n'existe pas, elle doit retourner null.
	 * 
	 * Inserez votre reponse ici
	 */
	public static Integer ceil(Node root, int value) {
        return null;
    }
}
