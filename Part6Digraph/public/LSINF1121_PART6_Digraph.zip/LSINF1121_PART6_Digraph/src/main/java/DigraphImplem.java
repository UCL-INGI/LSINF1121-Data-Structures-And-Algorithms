public class DigraphImplem implements Digraph {


    public DigraphImplem(int V) {
         // TODO
    }

    /**
     * The number of vertices
     */
    public int V() {
        // TODO
        return 0;
    }

    /**
     * The number of edges
     */
    public int E() {
        // TODO
        return 0;
    }

    /**
     * Add the edge v->w
     */
    public void addEdge(int v, int w) {
        // TODO
    }

    /**
     * The nodes adjacent to node v
     * that is the nodes w such that there is an edge v->w
     */
    public Iterable<Integer> adj(int v) {
        return null;
        // TODO
    }

    /**
     * A copy of the digraph with all edges reversed
     */
    public Digraph reverse() {
        return null;
        // TODO
    }


}
