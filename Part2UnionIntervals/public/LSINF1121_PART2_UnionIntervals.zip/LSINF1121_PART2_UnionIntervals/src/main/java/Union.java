public class Union {

    public static Interval [] union(Interval [] intervals) {
        // TODO
        return new Interval[]{};
    }

}
