import java.util.EmptyStackException;

public class MyStack<E> implements Stack<E> {

    @Override
    public boolean empty() {
        return false;
    }

    @Override
    public E peek() throws EmptyStackException {
        return null;
    }

    @Override
    public E pop() throws EmptyStackException {
        return null;
    }

    @Override
    public E push(E item) {
        return null;
    }
}
