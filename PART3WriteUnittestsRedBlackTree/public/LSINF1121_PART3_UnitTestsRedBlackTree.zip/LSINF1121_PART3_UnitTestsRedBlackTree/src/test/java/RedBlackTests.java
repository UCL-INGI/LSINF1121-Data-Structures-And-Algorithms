import org.junit.Test;

public class RedBlackTests {

    @Test
    public void firstTest() {
        // ... TODO ...
    }

    @Test
    public void secondTest() {
        // ... TODO ...
    }

}