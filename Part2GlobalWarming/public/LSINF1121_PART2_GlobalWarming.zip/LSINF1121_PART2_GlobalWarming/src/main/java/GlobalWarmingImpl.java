import java.util.*;

public class GlobalWarmingImpl extends GlobalWarming {

    public GlobalWarmingImpl(int[][] altitude) {
        super(altitude);
        // expected pre-processing time in the constructror : O(n^2 log(n^2))
        // TODO
    }


    public int nbSafePoints(int waterLevel) {
        // TODO
        // expected time complexity O(log(n^2))
        return 0;
    }

}