
public class Median {
	
    public static int median(Vector a, int lo, int hi) {
    	// TODO
        return a.get(0);
    }

}
